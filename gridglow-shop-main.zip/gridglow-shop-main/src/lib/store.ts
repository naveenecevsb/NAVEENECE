export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice: number;
  discount: number;
  rating: number;
  ratingCount: number;
  image: string;
  category: string;
  description: string;
  inStock: boolean;
}

export interface CartItem {
  productId: string;
  quantity: number;
}

const PRODUCT_STORAGE_KEY = "flipkart_products";
const CART_STORAGE_KEY = "flipkart_cart";
const CART_EVENT = "cart-updated";

const defaultProducts: Product[] = [
  {
    id: "1",
    name: "Samsung Galaxy S24 Ultra 5G",
    price: 74999,
    originalPrice: 134999,
    discount: 44,
    rating: 4.5,
    ratingCount: 12453,
    image: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=300&h=300&fit=crop",
    category: "Mobiles",
    description: "256GB, 12GB RAM, Titanium Gray",
    inStock: true,
  },
  {
    id: "2",
    name: "Apple MacBook Air M2",
    price: 89990,
    originalPrice: 119900,
    discount: 25,
    rating: 4.7,
    ratingCount: 8921,
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=300&h=300&fit=crop",
    category: "Laptops",
    description: "8GB RAM, 256GB SSD, Space Gray",
    inStock: true,
  },
  {
    id: "3",
    name: "Sony WH-1000XM5 Headphones",
    price: 22990,
    originalPrice: 34990,
    discount: 34,
    rating: 4.6,
    ratingCount: 5672,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&h=300&fit=crop",
    category: "Electronics",
    description: "Wireless Noise Cancelling",
    inStock: true,
  },
  {
    id: "4",
    name: "Nike Air Max 270 Running Shoes",
    price: 8995,
    originalPrice: 13995,
    discount: 36,
    rating: 4.3,
    ratingCount: 3421,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=300&h=300&fit=crop",
    category: "Fashion",
    description: "Men's Running Shoes, Black/White",
    inStock: true,
  },
  {
    id: "5",
    name: "Canon EOS R50 Mirrorless Camera",
    price: 62990,
    originalPrice: 79990,
    discount: 21,
    rating: 4.4,
    ratingCount: 1892,
    image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=300&h=300&fit=crop",
    category: "Electronics",
    description: "24.2MP, 4K Video, RF-S 18-45mm Lens",
    inStock: false,
  },
  {
    id: "6",
    name: "Boat Airdopes 141 TWS Earbuds",
    price: 1099,
    originalPrice: 4490,
    discount: 76,
    rating: 4.1,
    ratingCount: 45231,
    image: "https://images.unsplash.com/photo-1590658268037-6bf12f032f55?w=300&h=300&fit=crop",
    category: "Electronics",
    description: "42H Playtime, Bluetooth 5.3",
    inStock: true,
  },
  {
    id: "7",
    name: "Levi's Men's Slim Fit Jeans",
    price: 1799,
    originalPrice: 3599,
    discount: 50,
    rating: 4.2,
    ratingCount: 9874,
    image: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=300&h=300&fit=crop",
    category: "Fashion",
    description: "Stretchable, Dark Blue, All Sizes",
    inStock: true,
  },
  {
    id: "8",
    name: "Prestige Induction Cooktop",
    price: 2499,
    originalPrice: 4495,
    discount: 44,
    rating: 4.3,
    ratingCount: 6732,
    image: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300&h=300&fit=crop",
    category: "Home",
    description: "2000W, Push Button, Indian Menu",
    inStock: true,
  },
];

const emitCartUpdate = () => {
  window.dispatchEvent(new Event(CART_EVENT));
};

export function getProducts(): Product[] {
  try {
    const stored = localStorage.getItem(PRODUCT_STORAGE_KEY);
    if (stored) return JSON.parse(stored);
  } catch {}

  localStorage.setItem(PRODUCT_STORAGE_KEY, JSON.stringify(defaultProducts));
  return defaultProducts;
}

export function saveProducts(products: Product[]) {
  localStorage.setItem(PRODUCT_STORAGE_KEY, JSON.stringify(products));
}

export function getProductById(productId: string) {
  return getProducts().find((product) => product.id === productId);
}

export function getCart(): CartItem[] {
  try {
    const stored = localStorage.getItem(CART_STORAGE_KEY);
    if (stored) return JSON.parse(stored);
  } catch {}
  return [];
}

export function saveCart(cart: CartItem[]) {
  localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
  emitCartUpdate();
}

export function addToCart(productId: string, quantity = 1) {
  const cart = getCart();
  const existingItem = cart.find((item) => item.productId === productId);

  if (existingItem) {
    existingItem.quantity += quantity;
    saveCart([...cart]);
    return;
  }

  saveCart([...cart, { productId, quantity }]);
}

export function updateCartQuantity(productId: string, quantity: number) {
  if (quantity <= 0) {
    removeFromCart(productId);
    return;
  }

  const updatedCart = getCart().map((item) =>
    item.productId === productId ? { ...item, quantity } : item
  );

  saveCart(updatedCart);
}

export function removeFromCart(productId: string) {
  const updatedCart = getCart().filter((item) => item.productId !== productId);
  saveCart(updatedCart);
}

export function clearCart() {
  saveCart([]);
}

export function getCartCount() {
  return getCart().reduce((total, item) => total + item.quantity, 0);
}

export function getCartProducts() {
  return getCart()
    .map((item) => {
      const product = getProductById(item.productId);
      return product ? { ...product, quantity: item.quantity } : null;
    })
    .filter(Boolean) as Array<Product & { quantity: number }>;
}

export function getCartSubtotal() {
  return getCartProducts().reduce((total, item) => total + item.price * item.quantity, 0);
}

export const cartEventName = CART_EVENT;
export const categories = ["All", "Fashion", "Mobiles", "Electronics", "Beauty", "Home", "Laptops"];