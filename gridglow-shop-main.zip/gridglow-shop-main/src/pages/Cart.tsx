import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Minus, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import BottomNav from "@/components/BottomNav";
import {
  getCartProducts,
  getCartSubtotal,
  removeFromCart,
  updateCartQuantity,
} from "@/lib/store";
import { toast } from "sonner";

const Cart = () => {
  const navigate = useNavigate();
  const cartItems = getCartProducts();
  const subtotal = getCartSubtotal();
  const delivery = cartItems.length > 0 ? 49 : 0;
  const total = subtotal + delivery;

  return (
    <div className="min-h-screen bg-background pb-16">
      <header className="bg-primary sticky top-0 z-50 flex items-center gap-2 px-3 py-3">
        <Link to="/">
          <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary/80 h-8 w-8">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-primary-foreground font-bold text-lg">My Cart</h1>
      </header>

      <main className="px-3 py-4 space-y-3">
        {cartItems.length === 0 ? (
          <div className="bg-card rounded-lg border p-8 text-center">
            <p className="text-foreground font-medium">Your cart is empty</p>
            <p className="text-sm text-muted-foreground mt-1">Add products to continue</p>
            <Link to="/">
              <Button className="mt-4 bg-primary text-primary-foreground">Shop Now</Button>
            </Link>
          </div>
        ) : (
          <>
            <div className="space-y-2.5">
              {cartItems.map((item) => (
                <div key={item.id} className="bg-card rounded-lg border p-3 flex gap-3">
                  <img src={item.image} alt={item.name} className="w-20 h-20 object-contain bg-muted/30 rounded" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground line-clamp-2">{item.name}</p>
                    <p className="text-sm font-bold text-foreground mt-1">₹{item.price.toLocaleString()}</p>

                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-1.5">
                        <Button
                          size="icon"
                          variant="outline"
                          className="h-7 w-7"
                          onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </Button>
                        <span className="text-sm font-medium w-6 text-center">{item.quantity}</span>
                        <Button
                          size="icon"
                          variant="outline"
                          className="h-7 w-7"
                          onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </Button>
                      </div>

                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7 text-destructive hover:bg-destructive/10"
                        onClick={() => {
                          removeFromCart(item.id);
                          toast.success("Removed from cart");
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-card rounded-lg border p-4 space-y-2">
              <h2 className="text-sm font-bold text-foreground">Price Details</h2>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="text-foreground">₹{subtotal.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Delivery</span>
                <span className="text-foreground">₹{delivery.toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between font-bold text-base pt-1 border-t">
                <span className="text-foreground">Total</span>
                <span className="text-foreground">₹{total.toLocaleString()}</span>
              </div>
            </div>

            <Button
              className="w-full h-11 bg-secondary text-secondary-foreground hover:bg-secondary/90 font-bold"
              onClick={() => navigate("/checkout")}
            >
              Proceed to Checkout
            </Button>
          </>
        )}
      </main>

      <BottomNav />
    </div>
  );
};

export default Cart;
