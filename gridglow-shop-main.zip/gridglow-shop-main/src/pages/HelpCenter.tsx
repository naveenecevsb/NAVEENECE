import { ArrowLeft, HelpCircle, MessageCircle, Mail, Phone } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import BottomNav from "@/components/BottomNav";

const helpItems = [
  { icon: MessageCircle, label: "Chat with us", desc: "Get instant help from our team" },
  { icon: Mail, label: "Email Support", desc: "support@flipkart.com" },
  { icon: Phone, label: "Call Us", desc: "1800-xxx-xxxx (Toll Free)" },
];

const HelpCenter = () => (
  <div className="min-h-screen bg-background pb-16">
    <header className="bg-primary sticky top-0 z-50 flex items-center gap-3 px-3 py-3">
      <Link to="/account">
        <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary/80 h-8 w-8">
          <ArrowLeft className="h-5 w-5" />
        </Button>
      </Link>
      <h1 className="text-primary-foreground font-bold text-lg">Help Center</h1>
    </header>
    <div className="px-3 py-4 space-y-2.5">
      {helpItems.map((item) => {
        const Icon = item.icon;
        return (
          <button key={item.label} className="w-full bg-card rounded-lg border p-4 flex items-center gap-3 hover:shadow-sm transition-shadow text-left">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Icon className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">{item.label}</p>
              <p className="text-xs text-muted-foreground">{item.desc}</p>
            </div>
          </button>
        );
      })}
    </div>
    <BottomNav />
  </div>
);

export default HelpCenter;
