import { useState } from "react";
import { User, Heart, ChevronRight, Gift, HelpCircle, Package, LogOut, Store } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import Header from "@/components/Header";
import BottomNav from "@/components/BottomNav";
import { Link } from "react-router-dom";

const quickLinks = [
  { label: "Orders", icon: Package, color: "text-primary", path: "/orders" },
  { label: "Wishlist", icon: Heart, color: "text-pink-500", path: "/wishlist" },
  { label: "Coupons", icon: Gift, color: "text-green-600", path: "/coupons" },
  { label: "Help Center", icon: HelpCircle, color: "text-emerald-500", path: "/help" },
];

const Account = () => {
  const [displayName, setDisplayName] = useState("speedkart2k26");
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="min-h-screen bg-background pb-16">
      <Header searchQuery={searchQuery} onSearchChange={setSearchQuery} />

      <div className="px-3 py-4 space-y-3">
        {/* Profile Header */}
        <div className="bg-card rounded-lg border p-4 flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
            <User className="h-6 w-6 text-primary" />
          </div>
          <div>
            <p className="font-bold text-foreground">{displayName}</p>
            <p className="text-xs text-muted-foreground">{displayName}@gmail.com</p>
          </div>
        </div>

        {/* Quick Links Grid */}
        <div className="grid grid-cols-2 gap-2.5">
          {quickLinks.map((link) => {
            const Icon = link.icon;
            return (
              <Link
                key={link.label}
                to={link.path}
                className="bg-card rounded-lg border p-3 flex items-center gap-2.5 hover:shadow-sm transition-shadow"
              >
                <div className={`w-9 h-9 rounded-full flex items-center justify-center`}>
                  <Icon className={`h-5 w-5 ${link.color}`} />
                </div>
                <span className="text-sm font-medium text-foreground flex-1 text-left">{link.label}</span>
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </Link>
            );
          })}
        </div>

        {/* Edit Profile */}
        <div className="bg-card rounded-lg border p-4 space-y-3">
          <h3 className="font-bold text-foreground">Edit Profile</h3>

          <div>
            <label className="text-sm font-medium text-foreground mb-1 block">Display Name</label>
            <div className="flex gap-2">
              <Input
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="flex-1"
              />
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 font-medium px-4">
                Update Profile
              </Button>
            </div>
          </div>

          <Separator />

          <div className="flex gap-2">
            <Link to="/admin">
              <Button variant="outline" size="sm" className="gap-1.5 text-sm">
                <Store className="h-4 w-4" />
                Seller Dashboard
              </Button>
            </Link>
            <Button variant="outline" size="sm" className="gap-1.5 text-sm text-destructive border-destructive/30 hover:bg-destructive/10">
              <LogOut className="h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>

        {/* Order History */}
        <div className="bg-card rounded-lg border p-4">
          <div className="flex items-center gap-2 mb-3">
            <Package className="h-5 w-5 text-primary" />
            <h3 className="font-bold text-foreground">Order History</h3>
          </div>
          <p className="text-sm text-muted-foreground text-center py-6">No orders yet. Start shopping!</p>
        </div>
      </div>

      <BottomNav />
    </div>
  );
};

export default Account;
