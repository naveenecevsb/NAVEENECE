import { useState, useRef } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Plus, Pencil, Trash2, Package, Upload, ImageIcon, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { getProducts, saveProducts, categories, Product } from "@/lib/store";
import { toast } from "sonner";

const emptyProduct: Omit<Product, "id"> = {
  name: "",
  price: 0,
  originalPrice: 0,
  discount: 0,
  rating: 4.0,
  ratingCount: 0,
  image: "",
  category: "Electronics",
  description: "",
  inStock: true,
};

const Admin = () => {
  const [products, setProducts] = useState<Product[]>(getProducts());
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [form, setForm] = useState<Omit<Product, "id">>(emptyProduct);

  const handleSave = () => {
    if (!form.name || !form.price) {
      toast.error("Name and price are required");
      return;
    }

    let updated: Product[];
    if (editingProduct) {
      updated = products.map((p) =>
        p.id === editingProduct.id ? { ...form, id: editingProduct.id } : p
      );
      toast.success("Product updated");
    } else {
      const newProduct: Product = { ...form, id: Date.now().toString() };
      updated = [...products, newProduct];
      toast.success("Product added");
    }

    setProducts(updated);
    saveProducts(updated);
    setDialogOpen(false);
    setEditingProduct(null);
    setForm(emptyProduct);
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    const { id, ...rest } = product;
    setForm(rest);
    setDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    const updated = products.filter((p) => p.id !== id);
    setProducts(updated);
    saveProducts(updated);
    toast.success("Product deleted");
  };

  const handleAdd = () => {
    setEditingProduct(null);
    setForm(emptyProduct);
    setDialogOpen(true);
  };

  const updateField = (field: string, value: string | number | boolean) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Admin Header */}
      <header className="bg-primary sticky top-0 z-50 shadow-md">
        <div className="container flex items-center gap-3 py-3">
          <Link to="/">
            <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary/80">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <Package className="h-5 w-5 text-primary-foreground" />
            <h1 className="text-primary-foreground font-bold text-lg">Admin Panel</h1>
          </div>
          <div className="ml-auto">
            <Button onClick={handleAdd} size="sm" className="bg-secondary text-secondary-foreground hover:bg-secondary/90 gap-1.5 font-medium">
              <Plus className="h-4 w-4" />
              Add Product
            </Button>
          </div>
        </div>
      </header>

      <main className="container py-4">
        <div className="bg-card rounded-sm shadow-sm border overflow-hidden">
          <div className="p-4 border-b bg-muted/30">
            <h2 className="font-bold text-foreground">Products ({products.length})</h2>
          </div>

          <div className="divide-y">
            {products.map((product) => (
              <div key={product.id} className="flex items-center gap-3 p-3 hover:bg-muted/20 transition-colors">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-14 h-14 object-cover rounded-sm border"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{product.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {product.category} • ₹{product.price.toLocaleString()}
                    {!product.inStock && (
                      <span className="ml-2 text-destructive font-medium">Out of Stock</span>
                    )}
                  </p>
                </div>
                <div className="flex gap-1 shrink-0">
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-primary hover:bg-accent/10" onClick={() => handleEdit(product)}>
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:bg-destructive/10" onClick={() => handleDelete(product.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingProduct ? "Edit Product" : "Add Product"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-3 pt-2">
            <div>
              <Label className="text-xs">Product Name</Label>
              <Input value={form.name} onChange={(e) => updateField("name", e.target.value)} placeholder="Samsung Galaxy S24..." />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Price (₹)</Label>
                <Input type="number" value={form.price} onChange={(e) => updateField("price", Number(e.target.value))} />
              </div>
              <div>
                <Label className="text-xs">Original Price (₹)</Label>
                <Input type="number" value={form.originalPrice} onChange={(e) => updateField("originalPrice", Number(e.target.value))} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Discount %</Label>
                <Input type="number" value={form.discount} onChange={(e) => updateField("discount", Number(e.target.value))} />
              </div>
              <div>
                <Label className="text-xs">Category</Label>
                <Select value={form.category} onValueChange={(v) => updateField("category", v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.filter((c) => c !== "All").map((c) => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="text-xs">Product Image</Label>
              {form.image ? (
                <div className="relative mt-1 w-full h-32 rounded-lg border overflow-hidden bg-muted/30">
                  <img src={form.image} alt="Preview" className="w-full h-full object-contain" />
                  <button
                    type="button"
                    onClick={() => updateField("image", "")}
                    className="absolute top-1 right-1 bg-destructive text-destructive-foreground rounded-full p-1"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ) : (
                <label className="mt-1 flex flex-col items-center justify-center gap-2 border-2 border-dashed rounded-lg p-6 cursor-pointer hover:border-primary/50 hover:bg-muted/30 transition-colors">
                  <Upload className="h-8 w-8 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground font-medium">Click to upload image</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onloadend = () => {
                          updateField("image", reader.result as string);
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
                </label>
              )}
            </div>

            <div>
              <Label className="text-xs">Description</Label>
              <Input value={form.description} onChange={(e) => updateField("description", e.target.value)} placeholder="Brief description..." />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Rating</Label>
                <Input type="number" step="0.1" min="0" max="5" value={form.rating} onChange={(e) => updateField("rating", Number(e.target.value))} />
              </div>
              <div>
                <Label className="text-xs">Rating Count</Label>
                <Input type="number" value={form.ratingCount} onChange={(e) => updateField("ratingCount", Number(e.target.value))} />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Switch checked={form.inStock} onCheckedChange={(v) => updateField("inStock", v)} />
              <Label className="text-xs">In Stock</Label>
            </div>

            <Button onClick={handleSave} className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90 font-medium">
              {editingProduct ? "Update Product" : "Add Product"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Admin;
