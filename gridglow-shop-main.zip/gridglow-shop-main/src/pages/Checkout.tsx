import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { clearCart, getCartProducts, getCartSubtotal } from "@/lib/store";
import { toast } from "sonner";

const Checkout = () => {
  const navigate = useNavigate();
  const cartItems = getCartProducts();
  const subtotal = getCartSubtotal();
  const delivery = cartItems.length > 0 ? 49 : 0;
  const total = subtotal + delivery;

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");

  const placeOrder = () => {
    if (!name || !phone || !address) {
      toast.error("Please fill all checkout details");
      return;
    }

    clearCart();
    toast.success("Order placed successfully");
    navigate("/orders");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary sticky top-0 z-50 flex items-center gap-2 px-3 py-3">
        <Link to="/cart">
          <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary/80 h-8 w-8">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-primary-foreground font-bold text-lg">Checkout</h1>
      </header>

      <main className="px-3 py-4 space-y-3">
        {cartItems.length === 0 ? (
          <div className="bg-card rounded-lg border p-8 text-center">
            <CheckCircle2 className="h-10 w-10 text-success mx-auto mb-2" />
            <p className="text-foreground font-medium">No items to checkout</p>
            <Link to="/">
              <Button className="mt-4 bg-primary text-primary-foreground">Back to Home</Button>
            </Link>
          </div>
        ) : (
          <>
            <div className="bg-card rounded-lg border p-4 space-y-3">
              <h2 className="text-sm font-bold text-foreground">Delivery Details</h2>
              <div>
                <Label className="text-xs">Full Name</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter full name" />
              </div>
              <div>
                <Label className="text-xs">Phone Number</Label>
                <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Enter phone number" />
              </div>
              <div>
                <Label className="text-xs">Address</Label>
                <Input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Enter delivery address" />
              </div>
            </div>

            <div className="bg-card rounded-lg border p-4 space-y-2">
              <h2 className="text-sm font-bold text-foreground">Order Summary</h2>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Items ({cartItems.length})</span>
                <span className="text-foreground">₹{subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Delivery</span>
                <span className="text-foreground">₹{delivery.toLocaleString()}</span>
              </div>
              <div className="flex justify-between font-bold text-base border-t pt-1">
                <span className="text-foreground">Total Payable</span>
                <span className="text-foreground">₹{total.toLocaleString()}</span>
              </div>
            </div>

            <Button onClick={placeOrder} className="w-full h-11 bg-secondary text-secondary-foreground hover:bg-secondary/90 font-bold">
              Place Order
            </Button>
          </>
        )}
      </main>
    </div>
  );
};

export default Checkout;
