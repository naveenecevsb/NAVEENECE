import { Link } from "react-router-dom";
import { Shirt, Smartphone, Monitor, Sparkles, Home, Laptop, ChevronRight } from "lucide-react";
import BottomNav from "@/components/BottomNav";

const items = [
  { name: "Fashion", icon: Shirt, subtitle: "Clothing, Shoes, Accessories" },
  { name: "Mobiles", icon: Smartphone, subtitle: "Smartphones and accessories" },
  { name: "Electronics", icon: Monitor, subtitle: "Audio, Cameras, Gadgets" },
  { name: "Beauty", icon: Sparkles, subtitle: "Makeup and personal care" },
  { name: "Home", icon: Home, subtitle: "Kitchen and appliances" },
  { name: "Laptops", icon: Laptop, subtitle: "Notebooks and accessories" },
];

const Categories = () => (
  <div className="min-h-screen bg-background pb-16">
    <header className="bg-primary sticky top-0 z-50 px-3 py-3">
      <h1 className="text-primary-foreground font-bold text-lg">All Categories</h1>
    </header>

    <main className="px-3 py-4 space-y-2.5">
      {items.map((item) => {
        const Icon = item.icon;
        return (
          <Link
            key={item.name}
            to={`/categories/${encodeURIComponent(item.name)}`}
            className="bg-card rounded-lg border p-4 flex items-center gap-3"
          >
            <div className="w-11 h-11 rounded-full bg-primary/10 flex items-center justify-center">
              <Icon className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-foreground">{item.name}</p>
              <p className="text-xs text-muted-foreground">{item.subtitle}</p>
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </Link>
        );
      })}
    </main>

    <BottomNav />
  </div>
);

export default Categories;
