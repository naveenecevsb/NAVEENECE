import { useState, useMemo } from "react";
import Header from "@/components/Header";
import CategoryBar from "@/components/CategoryBar";
import BannerCarousel from "@/components/BannerCarousel";
import DealsSection from "@/components/DealsSection";
import ProductCard from "@/components/ProductCard";
import BottomNav from "@/components/BottomNav";
import { getProducts } from "@/lib/store";

const Index = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  const products = getProducts();

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const matchesCategory = activeCategory === "All" || p.category === activeCategory;
      const matchesSearch =
        !searchQuery ||
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [products, activeCategory, searchQuery]);

  return (
    <div className="min-h-screen bg-background pb-16">
      <Header searchQuery={searchQuery} onSearchChange={setSearchQuery} />
      <CategoryBar activeCategory={activeCategory} onCategoryChange={setActiveCategory} />
      <BannerCarousel />
      <DealsSection />

      <main className="px-3 py-4">
        <h2 className="text-lg font-bold text-foreground mb-3">Featured Products</h2>

        {filtered.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            <p className="text-lg font-medium">No products found</p>
            <p className="text-sm mt-1">Try a different search or category</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2.5">
            {filtered.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
};

export default Index;
