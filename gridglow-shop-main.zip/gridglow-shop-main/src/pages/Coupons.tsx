import { ArrowLeft, Gift } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import BottomNav from "@/components/BottomNav";

const Coupons = () => (
  <div className="min-h-screen bg-background pb-16">
    <header className="bg-primary sticky top-0 z-50 flex items-center gap-3 px-3 py-3">
      <Link to="/account">
        <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary/80 h-8 w-8">
          <ArrowLeft className="h-5 w-5" />
        </Button>
      </Link>
      <h1 className="text-primary-foreground font-bold text-lg">Coupons</h1>
    </header>
    <div className="px-3 py-4">
      <div className="bg-card rounded-lg border p-8 text-center">
        <Gift className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
        <p className="font-medium text-foreground">No coupons available</p>
        <p className="text-sm text-muted-foreground mt-1">Check back later for exclusive deals</p>
      </div>
    </div>
    <BottomNav />
  </div>
);

export default Coupons;
