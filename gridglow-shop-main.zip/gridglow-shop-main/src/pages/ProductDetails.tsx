import { Link, useParams } from "react-router-dom";
import { ArrowLeft, Star, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import BottomNav from "@/components/BottomNav";
import { addToCart, getProductById } from "@/lib/store";
import { toast } from "sonner";

const ProductDetails = () => {
  const { productId } = useParams();
  const product = productId ? getProductById(productId) : undefined;

  if (!product) {
    return (
      <div className="min-h-screen bg-background pb-16">
        <header className="bg-primary sticky top-0 z-50 px-3 py-3 text-primary-foreground font-bold">Product</header>
        <main className="px-3 py-6">
          <div className="bg-card rounded-lg border p-8 text-center">
            <p className="text-foreground font-medium">Product not found</p>
            <Link to="/">
              <Button className="mt-4 bg-primary text-primary-foreground">Go Home</Button>
            </Link>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-16">
      <header className="bg-primary sticky top-0 z-50 flex items-center gap-2 px-3 py-3">
        <Link to="/">
          <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary/80 h-8 w-8">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-primary-foreground font-bold text-lg line-clamp-1">Product Details</h1>
      </header>

      <main className="px-3 py-4 space-y-3">
        <div className="bg-card rounded-lg border p-4">
          <img src={product.image} alt={product.name} className="w-full h-64 object-contain" />
        </div>

        <div className="bg-card rounded-lg border p-4 space-y-2">
          <h2 className="text-lg font-bold text-foreground">{product.name}</h2>
          <p className="text-sm text-muted-foreground">{product.description}</p>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 bg-success text-success-foreground text-xs font-bold px-2 py-1 rounded-sm">
              {product.rating} <Star className="h-3 w-3 fill-current" />
            </span>
            <span className="text-xs text-muted-foreground">({product.ratingCount.toLocaleString()} ratings)</span>
          </div>
          <div className="flex items-baseline gap-2 pt-1">
            <span className="text-xl font-bold text-foreground">₹{product.price.toLocaleString()}</span>
            <span className="text-sm text-muted-foreground line-through">₹{product.originalPrice.toLocaleString()}</span>
            <span className="text-sm text-success font-semibold">{product.discount}% off</span>
          </div>
        </div>

        <Button
          disabled={!product.inStock}
          onClick={() => {
            addToCart(product.id);
            toast.success("Added to cart");
          }}
          className="w-full h-11 bg-secondary text-secondary-foreground hover:bg-secondary/90 font-bold gap-2"
        >
          <ShoppingCart className="h-4 w-4" />
          {product.inStock ? "Add to Cart" : "Out of Stock"}
        </Button>

        <Link to="/cart">
          <Button className="w-full h-11 bg-primary text-primary-foreground hover:bg-primary/90 font-bold">
            Go to Cart
          </Button>
        </Link>
      </main>

      <BottomNav />
    </div>
  );
};

export default ProductDetails;
