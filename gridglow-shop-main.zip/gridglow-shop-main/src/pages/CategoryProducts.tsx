import { Link, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import BottomNav from "@/components/BottomNav";
import { Button } from "@/components/ui/button";
import { getProducts } from "@/lib/store";

const CategoryProducts = () => {
  const { categoryName } = useParams();
  const decodedCategory = decodeURIComponent(categoryName || "");
  const products = getProducts().filter((product) => product.category === decodedCategory);

  return (
    <div className="min-h-screen bg-background pb-16">
      <header className="bg-primary sticky top-0 z-50 flex items-center gap-2 px-3 py-3">
        <Link to="/categories">
          <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary/80 h-8 w-8">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-primary-foreground font-bold text-lg">{decodedCategory || "Category"}</h1>
      </header>

      <main className="px-3 py-4">
        {products.length === 0 ? (
          <div className="bg-card rounded-lg border p-8 text-center text-muted-foreground">
            No products found in this category.
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2.5">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
};

export default CategoryProducts;
