import { useEffect, useState } from "react";
import { cartEventName, getCartCount } from "@/lib/store";

export const useCartCount = () => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const syncCount = () => setCount(getCartCount());

    syncCount();
    window.addEventListener(cartEventName, syncCount);
    window.addEventListener("storage", syncCount);

    return () => {
      window.removeEventListener(cartEventName, syncCount);
      window.removeEventListener("storage", syncCount);
    };
  }, []);

  return count;
};