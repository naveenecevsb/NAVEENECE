import { Home, LayoutGrid, User, ShoppingCart } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useCartCount } from "@/hooks/use-cart-count";

const tabs = [
  { label: "Home", icon: Home, path: "/" },
  { label: "Categories", icon: LayoutGrid, path: "/categories" },
  { label: "Account", icon: User, path: "/account" },
  { label: "Cart", icon: ShoppingCart, path: "/cart" },
];

const BottomNav = () => {
  const location = useLocation();
  const cartCount = useCartCount();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t z-50 pb-safe">
      <div className="flex items-center justify-around py-1.5">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = location.pathname === tab.path;
          return (
            <Link
              key={tab.label}
              to={tab.path}
              className={cn(
                "flex flex-col items-center gap-0.5 px-3 py-1 relative",
                isActive ? "text-primary" : "text-muted-foreground"
              )}
            >
              <div className="relative">
                <Icon className="h-5 w-5" strokeWidth={isActive ? 2.5 : 1.5} />
                {tab.label === "Cart" && cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-2 bg-destructive text-destructive-foreground text-[9px] font-bold min-w-4 h-4 px-1 rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </div>
              <span className="text-[10px] font-medium">{tab.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;