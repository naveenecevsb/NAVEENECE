import { Search, Heart, ShoppingCart, Menu } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { useCartCount } from "@/hooks/use-cart-count";

interface HeaderProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

const Header = ({ searchQuery, onSearchChange }: HeaderProps) => {
  const cartCount = useCartCount();

  return (
    <header className="bg-primary sticky top-0 z-50">
      <div className="flex items-center gap-2 px-3 py-2.5">
        <Link to="/admin">
          <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary/80 h-8 w-8">
            <Menu className="h-5 w-5" />
          </Button>
        </Link>

        <Link to="/" className="shrink-0">
          <div className="flex items-center gap-1">
            <div className="w-9 h-9 rounded-full bg-secondary flex items-center justify-center">
              <span className="text-secondary-foreground font-black text-sm">FK</span>
            </div>
          </div>
        </Link>

        <div className="ml-auto flex items-center gap-1">
          <Link to="/wishlist">
            <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary/80 h-8 w-8">
              <Heart className="h-5 w-5" />
            </Button>
          </Link>
          <Link to="/cart">
            <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary/80 h-8 w-8 relative">
              <ShoppingCart className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-secondary text-secondary-foreground text-[9px] font-bold min-w-4 h-4 px-1 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Button>
          </Link>
        </div>
      </div>

      <div className="px-3 pb-2.5">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search products..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-10 bg-card border-0 rounded-lg h-10 text-sm text-foreground placeholder:text-muted-foreground focus-visible:ring-1 focus-visible:ring-secondary"
          />
        </div>
      </div>
    </header>
  );
};

export default Header;