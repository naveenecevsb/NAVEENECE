import { Shirt, Smartphone, Monitor, Sparkles, Home as HomeIcon, Laptop } from "lucide-react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

interface CategoryBarProps {
  activeCategory: string;
  onCategoryChange: (cat: string) => void;
}

const categoryItems = [
  { name: "Fashion", icon: Shirt },
  { name: "Mobiles", icon: Smartphone },
  { name: "Electronics", icon: Monitor },
  { name: "Beauty", icon: Sparkles },
  { name: "Home", icon: HomeIcon },
  { name: "Laptops", icon: Laptop },
];

const CategoryBar = ({ activeCategory, onCategoryChange }: CategoryBarProps) => {
  return (
    <div className="bg-card border-b">
      <div className="flex items-center gap-2 px-2 py-3 overflow-x-auto">
        {categoryItems.map((cat) => {
          const Icon = cat.icon;
          const isActive = activeCategory === cat.name;
          return (
            <Link
              key={cat.name}
              to={`/categories/${encodeURIComponent(cat.name)}`}
              onClick={() => onCategoryChange(cat.name)}
              className={cn(
                "flex flex-col items-center gap-1 px-3 py-1 min-w-[68px] transition-colors shrink-0",
                isActive ? "text-primary" : "text-primary/70"
              )}
            >
              <Icon className={cn("h-6 w-6", isActive && "text-primary")} strokeWidth={1.5} />
              <span className="text-[11px] font-medium whitespace-nowrap">{cat.name}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
};

export default CategoryBar;