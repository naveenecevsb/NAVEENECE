import { Zap } from "lucide-react";

const deals = [
  { title: "Top Offers", subtitle: "Up to 80% Off", color: "border-secondary" },
  { title: "Phones & Tablets", subtitle: "From ₹6,999", color: "border-primary" },
  { title: "Fashion Deals", subtitle: "Min 50% Off", color: "border-success" },
  { title: "Home Appliances", subtitle: "From ₹499", color: "border-destructive" },
];

const DealsSection = () => {
  return (
    <div className="bg-card py-4 px-3">
      <div className="flex items-center gap-2 mb-3">
        <Zap className="h-5 w-5 text-secondary fill-secondary" />
        <h2 className="text-lg font-bold text-foreground">Deals of the Day</h2>
      </div>

      <div className="flex gap-3 overflow-x-auto pb-1 scrollbar-hide">
        {deals.map((deal) => (
          <button
            key={deal.title}
            className={`shrink-0 bg-card border-2 ${deal.color} rounded-lg px-5 py-3 min-w-[150px] text-left hover:shadow-md transition-shadow`}
          >
            <p className="text-sm font-bold text-foreground">{deal.title}</p>
            <p className="text-xs font-medium text-success mt-0.5">{deal.subtitle}</p>
          </button>
        ))}
      </div>
    </div>
  );
};

export default DealsSection;
