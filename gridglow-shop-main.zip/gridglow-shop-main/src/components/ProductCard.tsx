import { MouseEvent } from "react";
import { Star, ShoppingCart } from "lucide-react";
import { Link } from "react-router-dom";
import { Product, addToCart } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const handleAddToCart = (event: MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
    event.stopPropagation();

    if (!product.inStock) {
      toast.error("This product is out of stock");
      return;
    }

    addToCart(product.id);
    toast.success("Added to cart");
  };

  return (
    <Link to={`/product/${product.id}`} className="block">
      <article className="bg-card rounded-sm shadow-sm border hover:shadow-lg transition-shadow animate-slide-in cursor-pointer group overflow-hidden">
        <div className="relative aspect-square overflow-hidden bg-muted/30 p-4">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />
          {!product.inStock && (
            <div className="absolute inset-0 bg-foreground/40 flex items-center justify-center">
              <span className="bg-destructive text-destructive-foreground px-3 py-1 rounded-sm text-xs font-bold">
                OUT OF STOCK
              </span>
            </div>
          )}
        </div>

        <div className="p-3 space-y-1.5">
          <h3 className="text-sm font-medium text-foreground line-clamp-2 leading-tight">
            {product.name}
          </h3>
          <p className="text-xs text-muted-foreground line-clamp-1">{product.description}</p>

          <div className="flex items-center gap-1.5">
            <span className="inline-flex items-center gap-0.5 bg-success text-success-foreground text-[10px] font-bold px-1.5 py-0.5 rounded-sm">
              {product.rating} <Star className="h-2.5 w-2.5 fill-current" />
            </span>
            <span className="text-[10px] text-muted-foreground font-medium">
              ({product.ratingCount.toLocaleString()})
            </span>
          </div>

          <div className="flex items-baseline gap-2 pt-1">
            <span className="text-base font-bold text-foreground">
              ₹{product.price.toLocaleString()}
            </span>
            <span className="text-xs text-muted-foreground line-through">
              ₹{product.originalPrice.toLocaleString()}
            </span>
            <span className="text-xs font-medium text-success">
              {product.discount}% off
            </span>
          </div>

          <Button
            type="button"
            onClick={handleAddToCart}
            disabled={!product.inStock}
            className="w-full h-8 mt-2 bg-secondary text-secondary-foreground hover:bg-secondary/90 text-xs font-bold gap-1"
          >
            <ShoppingCart className="h-3.5 w-3.5" />
            {product.inStock ? "Add to Cart" : "Unavailable"}
          </Button>
        </div>
      </article>
    </Link>
  );
};

export default ProductCard;